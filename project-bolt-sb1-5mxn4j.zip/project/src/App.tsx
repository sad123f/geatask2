import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store/authStore';
import { Menu } from 'lucide-react';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Chat from './pages/Chat';
import Team from './pages/Team';
import Calendar from './pages/Calendar';
import Maps from './pages/Maps';
import Settings from './pages/Settings';
import Auth from './pages/Auth';
import SurveyPoints from './pages/SurveyPoints';
import Drawings from './pages/Drawings';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuthStore();
  return user ? children : <Navigate to="/auth" />;
}

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  return (
    <Router>
      <Routes>
        <Route path="/auth" element={<Auth />} />
        <Route
          path="/*"
          element={
            <PrivateRoute>
              <div className="min-h-screen bg-gray-50 capacitor-app" dir="rtl">
                <button
                  onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                  className="fixed top-4 right-4 z-50 p-2 bg-white rounded-lg shadow-lg md:hidden"
                >
                  <Menu className="w-6 h-6 text-gray-600" />
                </button>
                
                <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />
                
                <main className="md:mr-64 p-8 safe-area-top safe-area-bottom">
                  <Routes>
                    <Route path="/" element={<Dashboard />} />
                    <Route path="/chat" element={<Chat />} />
                    <Route path="/team" element={<Team />} />
                    <Route path="/calendar" element={<Calendar />} />
                    <Route path="/maps" element={<Maps />} />
                    <Route path="/survey-points" element={<SurveyPoints />} />
                    <Route path="/drawings" element={<Drawings />} />
                    <Route path="/settings" element={<Settings />} />
                  </Routes>
                </main>
              </div>
            </PrivateRoute>
          }
        />
      </Routes>
    </Router>
  );
}

export default App;