import { useState, useEffect, useCallback } from 'react';
import { getPeer, closePeer } from '../lib/peer';
import { socket } from '../lib/socket';

export interface Participant {
  id: string;
  name: string;
  stream?: MediaStream;
  audio: boolean;
  video: boolean;
}

export function useVideoCall(roomId: string) {
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [isConnecting, setIsConnecting] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const addParticipant = useCallback((participant: Participant) => {
    setParticipants(prev => {
      const exists = prev.find(p => p.id === participant.id);
      if (exists) {
        return prev.map(p => p.id === participant.id ? { ...p, ...participant } : p);
      }
      return [...prev, participant];
    });
  }, []);

  const removeParticipant = useCallback((participantId: string) => {
    setParticipants(prev => prev.filter(p => p.id !== participantId));
  }, []);

  const initializeCall = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: true
      });
      
      setLocalStream(stream);
      addParticipant({
        id: 'local',
        name: 'أنت',
        stream,
        audio: true,
        video: true
      });

      const peer = getPeer();
      
      peer.on('call', call => {
        call.answer(stream);
        
        call.on('stream', remoteStream => {
          addParticipant({
            id: call.peer,
            name: 'مشارك',
            stream: remoteStream,
            audio: true,
            video: true
          });
        });
      });

      socket.emit('join-room', { roomId });

      setIsConnecting(false);
    } catch (err) {
      setError('فشل في الوصول إلى الكاميرا والميكروفون');
      setIsConnecting(false);
    }
  }, [roomId, addParticipant]);

  const cleanup = useCallback(() => {
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
    }
    closePeer();
    socket.emit('leave-room', { roomId });
  }, [localStream, roomId]);

  useEffect(() => {
    initializeCall();
    return cleanup;
  }, [initializeCall, cleanup]);

  const toggleAudio = useCallback(() => {
    if (localStream) {
      const audioTrack = localStream.getAudioTracks()[0];
      audioTrack.enabled = !audioTrack.enabled;
      
      setParticipants(prev => 
        prev.map(p => p.id === 'local' ? { ...p, audio: audioTrack.enabled } : p)
      );

      socket.emit('toggle-audio', {
        roomId,
        enabled: audioTrack.enabled
      });
    }
  }, [localStream, roomId]);

  const toggleVideo = useCallback(() => {
    if (localStream) {
      const videoTrack = localStream.getVideoTracks()[0];
      videoTrack.enabled = !videoTrack.enabled;
      
      setParticipants(prev => 
        prev.map(p => p.id === 'local' ? { ...p, video: videoTrack.enabled } : p)
      );

      socket.emit('toggle-video', {
        roomId,
        enabled: videoTrack.enabled
      });
    }
  }, [localStream, roomId]);

  return {
    participants,
    isConnecting,
    error,
    toggleAudio,
    toggleVideo,
    cleanup
  };
}