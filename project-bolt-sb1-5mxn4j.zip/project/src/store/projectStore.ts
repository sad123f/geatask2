import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Project, ProjectFormData } from '../types/project';

interface ProjectState {
  projects: Project[];
  addProject: (project: ProjectFormData) => void;
  updateProject: (id: string, project: ProjectFormData) => void;
  deleteProject: (id: string) => void;
}

export const useProjectStore = create<ProjectState>()(
  persist(
    (set) => ({
      projects: [],
      addProject: (projectData) => set((state) => ({
        projects: [...state.projects, {
          ...projectData,
          id: Date.now().toString(),
        }],
      })),
      updateProject: (id, projectData) => set((state) => ({
        projects: state.projects.map((project) =>
          project.id === id ? { ...projectData, id } : project
        ),
      })),
      deleteProject: (id) => set((state) => ({
        projects: state.projects.filter((project) => project.id !== id),
      })),
    }),
    {
      name: 'project-storage',
    }
  )
);