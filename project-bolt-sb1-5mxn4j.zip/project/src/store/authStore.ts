import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface AuthState {
  user: any | null;
  setUser: (user: any) => void;
  phoneNumber: string;
  setPhoneNumber: (phone: string) => void;
  verificationCode: string;
  setVerificationCode: (code: string) => void;
  isAuthenticated: boolean;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      setUser: (user) => set({ user, isAuthenticated: !!user }),
      phoneNumber: '',
      setPhoneNumber: (phone) => set({ phoneNumber: phone }),
      verificationCode: '',
      setVerificationCode: (code) => set({ verificationCode: code }),
      isAuthenticated: false,
    }),
    {
      name: 'auth-storage',
    }
  )
);