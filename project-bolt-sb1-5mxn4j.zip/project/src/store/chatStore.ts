import { create } from 'zustand';
import { Message, ChatState } from '@/types/chat';
import { socket } from '@/lib/socket';

interface ChatStore extends ChatState {
  addMessage: (message: Message) => void;
  startCall: (type: 'video' | 'audio') => void;
  endCall: () => void;
}

export const useChatStore = create<ChatStore>((set) => ({
  messages: [],
  isCallActive: false,
  callType: null,
  activeRoomId: null,

  addMessage: (message) => set((state) => ({
    messages: [...state.messages, message]
  })),

  startCall: (type) => {
    const roomId = Date.now().toString();
    set({
      isCallActive: true,
      callType: type,
      activeRoomId: roomId
    });
    socket.emit('start-call', { roomId, type });
  },

  endCall: () => {
    set((state) => {
      if (state.activeRoomId) {
        socket.emit('end-call', { roomId: state.activeRoomId });
      }
      return {
        isCallActive: false,
        callType: null,
        activeRoomId: null
      };
    });
  }
}));