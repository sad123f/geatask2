import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { useDrawingStore } from '../store/drawingStore';
import { DRAWING_CATEGORIES, DrawingCategory } from '../types/drawing';
import DrawingList from '../components/drawings/DrawingList';
import DrawingUploader from '../components/drawings/DrawingUploader';
import toast from 'react-hot-toast';

export default function Drawings() {
  const [selectedCategory, setSelectedCategory] = useState<DrawingCategory>('construction');
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  
  const { drawings, addDrawing, deleteDrawing, getDrawingsByCategory } = useDrawingStore();
  const isAdmin = true; // In production, this would be determined by user roles

  const handleUpload = async (file: File) => {
    try {
      // Here you would typically upload the file to your storage service
      // For demo purposes, we'll create a fake URL
      const fakeUrl = URL.createObjectURL(file);
      
      addDrawing({
        name: file.name,
        category: selectedCategory,
        url: fakeUrl,
        uploadedBy: 'المستخدم الحالي',
        size: file.size,
      });

      setIsUploadOpen(false);
      toast.success('تم رفع الملف بنجاح');
    } catch (error) {
      toast.error('حدث خطأ أثناء رفع الملف');
    }
  };

  const handleDelete = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذا الملف؟')) {
      deleteDrawing(id);
      toast.success('تم حذف الملف بنجاح');
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold">اللوحات الهندسية</h2>
          {isAdmin && (
            <button
              onClick={() => setIsUploadOpen(true)}
              className="flex items-center space-x-2 space-x-reverse bg-emerald-500 text-white px-4 py-2 rounded-lg hover:bg-emerald-600 transition-colors"
            >
              <Plus className="w-5 h-5" />
              <span>رفع ملف جديد</span>
            </button>
          )}
        </div>

        <div className="flex space-x-4 space-x-reverse mb-6 overflow-x-auto pb-2">
          {Object.entries(DRAWING_CATEGORIES).map(([key, label]) => (
            <button
              key={key}
              onClick={() => setSelectedCategory(key as DrawingCategory)}
              className={`px-4 py-2 rounded-lg whitespace-nowrap ${
                selectedCategory === key
                  ? 'bg-emerald-500 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <DrawingList
          drawings={getDrawingsByCategory(selectedCategory)}
          onDelete={handleDelete}
          isAdmin={isAdmin}
        />
      </div>

      {isUploadOpen && (
        <DrawingUploader
          category={selectedCategory}
          onUpload={handleUpload}
          onClose={() => setIsUploadOpen(false)}
        />
      )}
    </div>
  );
}