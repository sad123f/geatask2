import React, { useEffect } from 'react';
import { useChatStore } from '@/store/chatStore';
import ChatContainer from '@/components/chat/ChatContainer';
import { socket } from '@/lib/socket';
import { Message } from '@/types/chat';

export default function Chat() {
  const {
    messages,
    isCallActive,
    activeRoomId,
    addMessage,
    startCall,
    endCall
  } = useChatStore();

  useEffect(() => {
    socket.on('receive-message', (message: Message) => {
      addMessage(message);
    });

    socket.on('call-started', ({ roomId, type }) => {
      startCall(type);
    });

    return () => {
      socket.off('receive-message');
      socket.off('call-started');
    };
  }, [addMessage, startCall]);

  const handleSendMessage = (text: string, files?: File[]) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      text,
      sender: 'user',
      timestamp: new Date(),
      attachments: files?.map((file, index) => ({
        id: `${Date.now()}-${index}`,
        type: 'file',
        url: URL.createObjectURL(file),
        name: file.name,
        size: `${(file.size / 1024).toFixed(1)} KB`,
      })),
    };

    addMessage(newMessage);
    socket.emit('send-message', newMessage);
  };

  const handleStartVideoCall = () => {
    startCall('video');
    
    const callMessage: Message = {
      id: Date.now().toString(),
      text: 'تم بدء مكالمة فيديو',
      sender: 'user',
      timestamp: new Date(),
      isVideoCall: true,
    };
    
    addMessage(callMessage);
  };

  const handleStartAudioCall = () => {
    startCall('audio');
    
    const callMessage: Message = {
      id: Date.now().toString(),
      text: 'تم بدء مكالمة صوتية',
      sender: 'user',
      timestamp: new Date(),
      isAudioCall: true,
    };
    
    addMessage(callMessage);
  };

  return (
    <ChatContainer
      messages={messages}
      onSendMessage={handleSendMessage}
      onStartVideoCall={handleStartVideoCall}
      onStartAudioCall={handleStartAudioCall}
      isCallActive={isCallActive}
      activeRoomId={activeRoomId}
      onEndCall={endCall}
    />
  );
}