import React, { useState } from 'react';
import { Plus, Download } from 'lucide-react';
import toast from 'react-hot-toast';
import * as XLSX from 'xlsx';
import { useAuthStore } from '../store/authStore';
import { useSurveyPointStore } from '../store/surveyPointStore';
import { SurveyPointFormData } from '../types/surveyPoint';
import SurveyPointForm from '../components/survey/SurveyPointForm';
import SurveyPointList from '../components/survey/SurveyPointList';

export default function SurveyPoints() {
  const [editingPoint, setEditingPoint] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<SurveyPointFormData>>({});
  
  const { user } = useAuthStore();
  const { points, addPoint, updatePoint, deletePoint } = useSurveyPointStore();
  
  const isAdmin = true; // In production, this would be determined by user roles

  const handleAddPoint = () => {
    if (!formData.pointNumber || !formData.easting || !formData.northing) {
      toast.error('يرجى ملء جميع الحقول المطلوبة');
      return;
    }

    addPoint(formData as SurveyPointFormData);
    setEditingPoint(null);
    setFormData({});
    toast.success('تمت إضافة النقطة بنجاح');
  };

  const handleUpdatePoint = (id: string) => {
    if (!formData.pointNumber || !formData.easting || !formData.northing) {
      toast.error('يرجى ملء جميع الحقول المطلوبة');
      return;
    }

    updatePoint(id, formData as SurveyPointFormData);
    setEditingPoint(null);
    setFormData({});
    toast.success('تم تحديث النقطة بنجاح');
  };

  const handleDeletePoint = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذه النقطة؟')) {
      deletePoint(id);
      toast.success('تم حذف النقطة بنجاح');
    }
  };

  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(points);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Survey Points');
    XLSX.writeFile(workbook, 'survey-points.xlsx');
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold">نقاط المسح</h2>
          <div className="flex space-x-4 space-x-reverse">
            <button
              onClick={exportToExcel}
              className="flex items-center space-x-2 space-x-reverse bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
            >
              <Download className="w-5 h-5" />
              <span>تصدير Excel</span>
            </button>
            {isAdmin && (
              <button
                onClick={() => setEditingPoint('new')}
                className="flex items-center space-x-2 space-x-reverse bg-emerald-500 text-white px-4 py-2 rounded-lg hover:bg-emerald-600 transition-colors"
              >
                <Plus className="w-5 h-5" />
                <span>إضافة نقطة</span>
              </button>
            )}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50">
                <th className="px-4 py-3 text-right">رقم النقطة</th>
                <th className="px-4 py-3 text-right">E</th>
                <th className="px-4 py-3 text-right">N</th>
                <th className="px-4 py-3 text-right">المنسوب</th>
                <th className="px-4 py-3 text-right">ملاحظات</th>
                {isAdmin && <th className="px-4 py-3 text-right">إجراءات</th>}
              </tr>
            </thead>
            {editingPoint === 'new' && (
              <tbody>
                <SurveyPointForm
                  point={formData}
                  onChange={setFormData}
                  onSave={handleAddPoint}
                  onCancel={() => {
                    setEditingPoint(null);
                    setFormData({});
                  }}
                />
              </tbody>
            )}
            <SurveyPointList
              points={points}
              onEdit={(point) => {
                setEditingPoint(point.id);
                setFormData(point);
              }}
              onDelete={handleDeletePoint}
              isAdmin={isAdmin}
            />
          </table>
        </div>
      </div>
    </div>
  );
}