import React from 'react';
import { User, Bell, Shield, Globe, Phone, Mail } from 'lucide-react';

export default function Settings() {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h2 className="text-xl font-semibold mb-6">الإعدادات</h2>
        
        <div className="space-y-6">
          <div className="border-b pb-6">
            <h3 className="text-lg font-medium mb-4">الملف الشخصي</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">الاسم</label>
                <input
                  type="text"
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">البريد الإلكتروني</label>
                <input
                  type="email"
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          <div className="border-b pb-6">
            <h3 className="text-lg font-medium mb-4">الإشعارات</h3>
            <div className="space-y-4">
              <label className="flex items-center space-x-3 space-x-reverse">
                <input type="checkbox" className="form-checkbox text-emerald-500" />
                <span>إشعارات البريد الإلكتروني</span>
              </label>
              <label className="flex items-center space-x-3 space-x-reverse">
                <input type="checkbox" className="form-checkbox text-emerald-500" />
                <span>إشعارات التطبيق</span>
              </label>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-medium mb-4">معلومات المطور</h3>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="space-y-2">
                <p className="flex items-center space-x-2 space-x-reverse">
                  <User className="w-5 h-5 text-gray-500" />
                  <span>السيد أشرف السيد</span>
                </p>
                <p className="flex items-center space-x-2 space-x-reverse">
                  <Phone className="w-5 h-5 text-gray-500" />
                  <span dir="ltr">+20 102 457 8489</span>
                </p>
                <p className="flex items-center space-x-2 space-x-reverse">
                  <Mail className="w-5 h-5 text-gray-500" />
                  <span>ea4019273@gmail.com</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}