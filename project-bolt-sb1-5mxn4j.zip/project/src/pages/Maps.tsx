import React from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { Icon } from 'leaflet';

const defaultIcon = new Icon({
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

export default function Maps() {
  const projects = [
    {
      id: 1,
      name: 'مسح أراضي الرياض الشمالية',
      location: [24.7136, 46.6753],
      status: 'جاري العمل',
    },
    {
      id: 2,
      name: 'تطوير منطقة القصيم',
      location: [26.3268, 43.9719],
      status: 'مكتمل',
    },
  ];

  return (
    <div className="h-[calc(100vh-2rem)]">
      <div className="bg-white p-6 rounded-lg shadow-sm h-full">
        <h2 className="text-xl font-semibold mb-6">الخرائط</h2>
        <MapContainer
          center={[24.7136, 46.6753]}
          zoom={6}
          style={{ height: 'calc(100% - 4rem)' }}
        >
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          />
          {projects.map((project) => (
            <Marker
              key={project.id}
              position={project.location as [number, number]}
              icon={defaultIcon}
            >
              <Popup>
                <div className="text-right">
                  <h3 className="font-semibold">{project.name}</h3>
                  <p className="text-sm text-gray-600">{project.status}</p>
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      </div>
    </div>
  );
}