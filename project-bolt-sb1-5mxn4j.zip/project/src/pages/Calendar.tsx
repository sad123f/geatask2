import React, { useState } from 'react';
import { Calendar as BigCalendar, dateFnsLocalizer } from 'react-big-calendar';
import format from 'date-fns/format';
import parse from 'date-fns/parse';
import startOfWeek from 'date-fns/startOfWeek';
import getDay from 'date-fns/getDay';
import arSA from 'date-fns/locale/ar-SA';
import { Dialog } from '@headlessui/react';
import { Video, Plus, X, Users, Clock, MapPin } from 'lucide-react';
import toast from 'react-hot-toast';
import 'react-big-calendar/lib/css/react-big-calendar.css';

const locales = {
  'ar-SA': arSA,
};

const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek,
  getDay,
  locales,
});

interface Meeting {
  id: string;
  title: string;
  start: Date;
  end: Date;
  location?: string;
  attendees: string[];
  videoUrl?: string;
}

export default function Calendar() {
  const [meetings, setMeetings] = useState<Meeting[]>([
    {
      id: '1',
      title: 'مراجعة مشروع الرياض الشمالية',
      start: new Date(2024, 2, 15, 10, 0),
      end: new Date(2024, 2, 15, 11, 30),
      location: 'غرفة اجتماعات افتراضية',
      attendees: ['أحمد محمد', 'سارة خالد', 'محمد علي'],
      videoUrl: 'https://meet.example.com/123',
    },
  ]);

  const [isOpen, setIsOpen] = useState(false);
  const [newMeeting, setNewMeeting] = useState<Partial<Meeting>>({
    title: '',
    start: new Date(),
    end: new Date(),
    location: '',
    attendees: [],
    videoUrl: '',
  });

  const handleAddMeeting = () => {
    if (!newMeeting.title || !newMeeting.start || !newMeeting.end) {
      toast.error('يرجى ملء جميع الحقول المطلوبة');
      return;
    }

    const meeting: Meeting = {
      id: Date.now().toString(),
      title: newMeeting.title,
      start: newMeeting.start,
      end: newMeeting.end,
      location: newMeeting.location,
      attendees: newMeeting.attendees || [],
      videoUrl: newMeeting.videoUrl,
    };

    setMeetings([...meetings, meeting]);
    setIsOpen(false);
    toast.success('تم إضافة الاجتماع بنجاح');
    
    // Here you would typically send notifications to attendees
    meeting.attendees.forEach(attendee => {
      console.log(`Sending notification to ${attendee}`);
    });
  };

  const handleSelectSlot = ({ start, end }: { start: Date; end: Date }) => {
    setNewMeeting({ ...newMeeting, start, end });
    setIsOpen(true);
  };

  const handleSelectEvent = (event: Meeting) => {
    if (event.videoUrl) {
      window.open(event.videoUrl, '_blank');
    }
  };

  return (
    <div className="h-[calc(100vh-2rem)]">
      <div className="bg-white p-6 rounded-lg shadow-sm h-full">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold">التقويم</h2>
          <button
            onClick={() => setIsOpen(true)}
            className="flex items-center space-x-2 space-x-reverse bg-emerald-500 text-white px-4 py-2 rounded-lg hover:bg-emerald-600 transition-colors"
          >
            <Plus className="w-5 h-5" />
            <span>إضافة اجتماع</span>
          </button>
        </div>

        <BigCalendar
          localizer={localizer}
          events={meetings}
          startAccessor="start"
          endAccessor="end"
          style={{ height: 'calc(100% - 4rem)' }}
          messages={{
            next: 'التالي',
            previous: 'السابق',
            today: 'اليوم',
            month: 'شهر',
            week: 'أسبوع',
            day: 'يوم',
          }}
          selectable
          onSelectSlot={handleSelectSlot}
          onSelectEvent={handleSelectEvent}
        />

        <Dialog open={isOpen} onClose={() => setIsOpen(false)} className="relative z-50">
          <div className="fixed inset-0 bg-black/30" aria-hidden="true" />
          <div className="fixed inset-0 flex items-center justify-center p-4">
            <Dialog.Panel className="bg-white rounded-lg p-6 max-w-md w-full">
              <div className="flex justify-between items-center mb-4">
                <Dialog.Title className="text-lg font-semibold">إضافة اجتماع جديد</Dialog.Title>
                <button onClick={() => setIsOpen(false)}>
                  <X className="w-5 h-5 text-gray-500" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">عنوان الاجتماع</label>
                  <input
                    type="text"
                    value={newMeeting.title}
                    onChange={(e) => setNewMeeting({ ...newMeeting, title: e.target.value })}
                    className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">وقت البدء</label>
                    <input
                      type="datetime-local"
                      value={format(newMeeting.start || new Date(), "yyyy-MM-dd'T'HH:mm")}
                      onChange={(e) => setNewMeeting({ ...newMeeting, start: new Date(e.target.value) })}
                      className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">وقت الانتهاء</label>
                    <input
                      type="datetime-local"
                      value={format(newMeeting.end || new Date(), "yyyy-MM-dd'T'HH:mm")}
                      onChange={(e) => setNewMeeting({ ...newMeeting, end: new Date(e.target.value) })}
                      className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">المكان</label>
                  <input
                    type="text"
                    value={newMeeting.location}
                    onChange={(e) => setNewMeeting({ ...newMeeting, location: e.target.value })}
                    className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
                    placeholder="غرفة اجتماعات افتراضية"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">رابط الفيديو</label>
                  <input
                    type="url"
                    value={newMeeting.videoUrl}
                    onChange={(e) => setNewMeeting({ ...newMeeting, videoUrl: e.target.value })}
                    className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
                    placeholder="https://meet.example.com/..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">المشاركون</label>
                  <input
                    type="text"
                    value={newMeeting.attendees?.join(', ')}
                    onChange={(e) => setNewMeeting({ ...newMeeting, attendees: e.target.value.split(',').map(s => s.trim()) })}
                    className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
                    placeholder="أدخل أسماء المشاركين مفصولة بفواصل"
                  />
                </div>

                <button
                  onClick={handleAddMeeting}
                  className="w-full bg-emerald-500 text-white py-2 rounded-lg hover:bg-emerald-600 transition-colors"
                >
                  إضافة الاجتماع
                </button>
              </div>
            </Dialog.Panel>
          </div>
        </Dialog>
      </div>
    </div>
  );
}