export interface Participant {
  id: string;
  name: string;
  stream?: MediaStream;
  audio: boolean;
  video: boolean;
}

export interface VideoCallProps {
  roomId: string;
  onClose: () => void;
}