export interface Message {
  id: string;
  text: string;
  sender: 'user' | 'other';
  timestamp: Date;
  attachments?: {
    id: string;
    type: 'file' | 'image' | 'audio' | 'video';
    url: string;
    name: string;
    size: string;
  }[];
  isVideoCall?: boolean;
  isAudioCall?: boolean;
}

export interface ChatState {
  messages: Message[];
  isCallActive: boolean;
  callType: 'video' | 'audio' | null;
  activeRoomId: string | null;
}