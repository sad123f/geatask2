import React from 'react';
import VideoParticipant from './VideoParticipant';
import { Participant } from '@/types/video';

interface VideoGridProps {
  participants: Participant[];
}

export default function VideoGrid({ participants }: VideoGridProps) {
  return (
    <div className="flex-1 p-4">
      <div className={`grid gap-4 h-full ${
        participants.length <= 1 ? 'grid-cols-1' :
        participants.length <= 4 ? 'grid-cols-2' :
        'grid-cols-3'
      }`}>
        {participants.map((participant) => (
          <VideoParticipant
            key={participant.id}
            participant={participant}
          />
        ))}
      </div>
    </div>
  );
}