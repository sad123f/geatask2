import React from 'react';
import { Camera, CameraOff, Mic, MicOff, PhoneOff } from 'lucide-react';

interface VideoControlsProps {
  isAudioEnabled: boolean;
  isVideoEnabled: boolean;
  onToggleAudio: () => void;
  onToggleVideo: () => void;
  onEndCall: () => void;
}

export default function VideoControls({
  isAudioEnabled,
  isVideoEnabled,
  onToggleAudio,
  onToggleVideo,
  onEndCall,
}: VideoControlsProps) {
  return (
    <div className="flex items-center space-x-4 space-x-reverse">
      <button
        onClick={onToggleAudio}
        className={`p-3 rounded-full ${
          isAudioEnabled ? 'bg-gray-600' : 'bg-red-500'
        }`}
        aria-label={isAudioEnabled ? 'كتم الصوت' : 'تشغيل الصوت'}
      >
        {isAudioEnabled ? (
          <Mic className="w-5 h-5 text-white" />
        ) : (
          <MicOff className="w-5 h-5 text-white" />
        )}
      </button>
      <button
        onClick={onToggleVideo}
        className={`p-3 rounded-full ${
          isVideoEnabled ? 'bg-gray-600' : 'bg-red-500'
        }`}
        aria-label={isVideoEnabled ? 'إيقاف الكاميرا' : 'تشغيل الكاميرا'}
      >
        {isVideoEnabled ? (
          <Camera className="w-5 h-5 text-white" />
        ) : (
          <CameraOff className="w-5 h-5 text-white" />
        )}
      </button>
      <button
        onClick={onEndCall}
        className="p-3 rounded-full bg-red-500"
        aria-label="إنهاء المكالمة"
      >
        <PhoneOff className="w-5 h-5 text-white" />
      </button>
    </div>
  );
}