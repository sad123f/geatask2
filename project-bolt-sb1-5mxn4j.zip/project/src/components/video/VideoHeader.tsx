import React from 'react';
import { Users } from 'lucide-react';

interface VideoHeaderProps {
  participantCount: number;
}

export default function VideoHeader({ participantCount }: VideoHeaderProps) {
  return (
    <div className="p-4 flex justify-between items-center bg-gray-800">
      <div className="flex items-center space-x-3 space-x-reverse">
        <Users className="w-5 h-5 text-white" />
        <span className="text-white">{participantCount} مشاركين</span>
      </div>
    </div>
  );
}