import React from 'react';
import { useVideoCall } from '@/hooks/useVideoCall';
import VideoHeader from './VideoHeader';
import VideoControls from './VideoControls';
import VideoGrid from './VideoGrid';
import { VideoCallProps } from '@/types/video';
import toast from 'react-hot-toast';

export default function VideoCall({ roomId, onClose }: VideoCallProps) {
  const {
    participants,
    isConnecting,
    error,
    toggleAudio,
    toggleVideo,
    cleanup
  } = useVideoCall(roomId);

  const localParticipant = participants.find(p => p.id === 'local');
  const isAudioEnabled = localParticipant?.audio ?? true;
  const isVideoEnabled = localParticipant?.video ?? true;

  const handleClose = () => {
    cleanup();
    onClose();
  };

  if (error) {
    toast.error(error);
    handleClose();
    return null;
  }

  if (isConnecting) {
    return (
      <div className="fixed inset-0 bg-gray-900 flex items-center justify-center">
        <div className="text-white text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-white border-t-transparent mx-auto mb-4"></div>
          <p>جاري الاتصال...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-gray-900 flex flex-col">
      <VideoHeader participantCount={participants.length} />
      <VideoGrid participants={participants} />
      <div className="p-4 flex justify-center bg-gray-800">
        <VideoControls
          isAudioEnabled={isAudioEnabled}
          isVideoEnabled={isVideoEnabled}
          onToggleAudio={toggleAudio}
          onToggleVideo={toggleVideo}
          onEndCall={handleClose}
        />
      </div>
    </div>
  );
}