import React, { useState, useRef } from 'react';
import { Paperclip, Send, Video, Mic } from 'lucide-react';

interface ChatInputProps {
  onSendMessage: (text: string, files?: File[]) => void;
  onStartVideoCall: () => void;
  onStartAudioCall: () => void;
}

export default function ChatInput({ onSendMessage, onStartVideoCall, onStartAudioCall }: ChatInputProps) {
  const [message, setMessage] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);

  const handleSend = () => {
    if (message.trim() || selectedFiles.length > 0) {
      onSendMessage(message, selectedFiles);
      setMessage('');
      setSelectedFiles([]);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setSelectedFiles(Array.from(e.target.files));
    }
  };

  return (
    <div className="border-t p-4">
      {selectedFiles.length > 0 && (
        <div className="mb-4 p-2 bg-gray-50 rounded-lg">
          <div className="text-sm font-medium mb-2">الملفات المرفقة:</div>
          {selectedFiles.map((file, index) => (
            <div key={index} className="text-sm text-gray-600">
              {file.name} ({(file.size / 1024).toFixed(1)} KB)
            </div>
          ))}
        </div>
      )}

      <div className="flex items-center space-x-4 space-x-reverse">
        <button
          onClick={onStartVideoCall}
          className="p-2 hover:bg-gray-100 rounded-full"
          title="بدء مكالمة فيديو"
        >
          <Video className="w-5 h-5 text-gray-500" />
        </button>
        
        <button
          onClick={onStartAudioCall}
          className="p-2 hover:bg-gray-100 rounded-full"
          title="بدء مكالمة صوتية"
        >
          <Mic className="w-5 h-5 text-gray-500" />
        </button>

        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          multiple
          className="hidden"
          accept=".pdf,.doc,.docx,.dwg,.jpg,.jpeg,.png"
        />
        
        <button
          onClick={() => fileInputRef.current?.click()}
          className="p-2 hover:bg-gray-100 rounded-full"
          title="إرفاق ملف"
        >
          <Paperclip className="w-5 h-5 text-gray-500" />
        </button>

        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSend()}
          placeholder="اكتب رسالتك هنا..."
          className="flex-1 bg-gray-100 rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500"
        />

        <button
          onClick={handleSend}
          className="p-2 bg-emerald-500 text-white rounded-full hover:bg-emerald-600"
        >
          <Send className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}