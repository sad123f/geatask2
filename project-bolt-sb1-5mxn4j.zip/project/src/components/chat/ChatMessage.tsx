import React from 'react';
import { FileText, Download, Video, Mic } from 'lucide-react';
import { format } from 'date-fns';
import { arSA } from 'date-fns/locale';

interface Attachment {
  id: string;
  type: 'file' | 'image' | 'audio' | 'video';
  url: string;
  name: string;
  size: string;
}

interface ChatMessageProps {
  id: string;
  text: string;
  sender: 'user' | 'other';
  timestamp: Date;
  attachments?: Attachment[];
  isVideoCall?: boolean;
  isAudioCall?: boolean;
}

export default function ChatMessage({
  text,
  sender,
  timestamp,
  attachments,
  isVideoCall,
  isAudioCall,
}: ChatMessageProps) {
  const isOutgoing = sender === 'user';

  return (
    <div className={`flex ${isOutgoing ? 'justify-end' : 'justify-start'} mb-4`}>
      <div
        className={`max-w-[70%] rounded-lg p-3 ${
          isOutgoing ? 'bg-emerald-500 text-white' : 'bg-gray-100 text-gray-800'
        }`}
      >
        {(isVideoCall || isAudioCall) && (
          <div className="flex items-center space-x-2 space-x-reverse mb-2">
            {isVideoCall ? (
              <Video className={`w-5 h-5 ${isOutgoing ? 'text-white' : 'text-emerald-500'}`} />
            ) : (
              <Mic className={`w-5 h-5 ${isOutgoing ? 'text-white' : 'text-emerald-500'}`} />
            )}
            <span>مكالمة {isVideoCall ? 'فيديو' : 'صوتية'}</span>
          </div>
        )}

        <p className="mb-1">{text}</p>

        {attachments && attachments.length > 0 && (
          <div className="space-y-2 mt-2">
            {attachments.map((attachment) => (
              <div
                key={attachment.id}
                className={`flex items-center space-x-2 space-x-reverse p-2 rounded ${
                  isOutgoing ? 'bg-emerald-600' : 'bg-gray-200'
                }`}
              >
                <FileText className="w-4 h-4" />
                <span className="flex-1 truncate">{attachment.name}</span>
                <span className="text-sm opacity-75">{attachment.size}</span>
                <button className="p-1 hover:bg-black/10 rounded">
                  <Download className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}

        <span
          className={`text-xs block mt-1 ${
            isOutgoing ? 'text-emerald-100' : 'text-gray-500'
          }`}
        >
          {format(timestamp, 'p', { locale: arSA })}
        </span>
      </div>
    </div>
  );
}