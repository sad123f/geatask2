import React from 'react';
import ChatMessage from './ChatMessage';
import ChatInput from './ChatInput';
import VideoCall from '../video/VideoCall';
import { Message } from '@/types/chat';

interface ChatContainerProps {
  messages: Message[];
  onSendMessage: (text: string, files?: File[]) => void;
  onStartVideoCall: () => void;
  onStartAudioCall: () => void;
  isCallActive: boolean;
  activeRoomId: string | null;
  onEndCall: () => void;
}

export default function ChatContainer({
  messages,
  onSendMessage,
  onStartVideoCall,
  onStartAudioCall,
  isCallActive,
  activeRoomId,
  onEndCall,
}: ChatContainerProps) {
  return (
    <div className="h-[calc(100vh-2rem)] flex flex-col">
      <div className="bg-white p-4 rounded-lg shadow-sm mb-4">
        <h2 className="text-xl font-semibold">الدردشة</h2>
      </div>

      <div className="flex-1 bg-white rounded-lg shadow-sm overflow-hidden flex flex-col">
        <div className="flex-1 overflow-y-auto p-4">
          {messages.map((message) => (
            <ChatMessage key={message.id} {...message} />
          ))}
        </div>

        <ChatInput
          onSendMessage={onSendMessage}
          onStartVideoCall={onStartVideoCall}
          onStartAudioCall={onStartAudioCall}
        />
      </div>

      {isCallActive && activeRoomId && (
        <VideoCall
          roomId={activeRoomId}
          onClose={onEndCall}
        />
      )}
    </div>
  );
}