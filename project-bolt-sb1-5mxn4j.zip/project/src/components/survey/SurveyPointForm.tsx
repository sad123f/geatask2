import React from 'react';
import { Save, X } from 'lucide-react';
import { SurveyPointFormData } from '../../types/surveyPoint';

interface SurveyPointFormProps {
  point: Partial<SurveyPointFormData>;
  onChange: (point: Partial<SurveyPointFormData>) => void;
  onSave: () => void;
  onCancel: () => void;
}

export default function SurveyPointForm({
  point,
  onChange,
  onSave,
  onCancel,
}: SurveyPointFormProps) {
  return (
    <tr className="border-b">
      <td className="px-4 py-3">
        <input
          type="text"
          value={point.pointNumber || ''}
          onChange={(e) => onChange({ ...point, pointNumber: e.target.value })}
          className="w-full p-2 border rounded"
          placeholder="رقم النقطة"
        />
      </td>
      <td className="px-4 py-3">
        <input
          type="number"
          value={point.easting || ''}
          onChange={(e) => onChange({ ...point, easting: Number(e.target.value) })}
          className="w-full p-2 border rounded"
          placeholder="E"
        />
      </td>
      <td className="px-4 py-3">
        <input
          type="number"
          value={point.northing || ''}
          onChange={(e) => onChange({ ...point, northing: Number(e.target.value) })}
          className="w-full p-2 border rounded"
          placeholder="N"
        />
      </td>
      <td className="px-4 py-3">
        <input
          type="number"
          value={point.elevation || ''}
          onChange={(e) => onChange({ ...point, elevation: Number(e.target.value) })}
          className="w-full p-2 border rounded"
          placeholder="المنسوب"
        />
      </td>
      <td className="px-4 py-3">
        <input
          type="text"
          value={point.notes || ''}
          onChange={(e) => onChange({ ...point, notes: e.target.value })}
          className="w-full p-2 border rounded"
          placeholder="ملاحظات"
        />
      </td>
      <td className="px-4 py-3">
        <div className="flex space-x-2 space-x-reverse">
          <button
            onClick={onSave}
            className="p-2 text-emerald-500 hover:text-emerald-600"
          >
            <Save className="w-5 h-5" />
          </button>
          <button
            onClick={onCancel}
            className="p-2 text-red-500 hover:text-red-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </td>
    </tr>
  );
}