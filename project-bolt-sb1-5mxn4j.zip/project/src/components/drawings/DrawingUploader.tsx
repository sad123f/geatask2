import React, { useRef } from 'react';
import { Upload, X } from 'lucide-react';
import { DrawingCategory } from '../../types/drawing';
import toast from 'react-hot-toast';

interface DrawingUploaderProps {
  category: DrawingCategory;
  onUpload: (file: File) => void;
  onClose: () => void;
}

export default function DrawingUploader({
  category,
  onUpload,
  onClose,
}: DrawingUploaderProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.dwg')) {
      toast.error('يرجى اختيار ملف بصيغة DWG');
      return;
    }

    if (file.size > 100 * 1024 * 1024) { // 100MB limit
      toast.error('حجم الملف كبير جداً. الحد الأقصى 100 ميجابايت');
      return;
    }

    onUpload(file);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">رفع ملف DWG جديد</h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div
          className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-emerald-500 transition-colors"
          onClick={() => fileInputRef.current?.click()}
        >
          <Upload className="w-12 h-12 mx-auto text-gray-400 mb-4" />
          <p className="text-gray-600">اضغط هنا لاختيار ملف DWG</p>
          <p className="text-sm text-gray-500 mt-2">أو اسحب الملف وأفلته هنا</p>
        </div>

        <input
          ref={fileInputRef}
          type="file"
          accept=".dwg"
          onChange={handleFileChange}
          className="hidden"
        />
      </div>
    </div>
  );
}