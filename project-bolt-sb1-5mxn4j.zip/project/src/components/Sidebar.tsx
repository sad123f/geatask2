import React from 'react';
import { MessageSquare, FolderKanban, Users, Calendar, Settings, Map, Table, FileText, X } from 'lucide-react';
import { NavLink } from 'react-router-dom';

const menuItems = [
  { icon: FolderKanban, label: 'المشاريع', path: '/' },
  { icon: Table, label: 'نقاط المسح', path: '/survey-points' },
  { icon: FileText, label: 'اللوحات الهندسية', path: '/drawings' },
  { icon: MessageSquare, label: 'الدردشة', path: '/chat' },
  { icon: Users, label: 'الفريق', path: '/team' },
  { icon: Calendar, label: 'التقويم', path: '/calendar' },
  { icon: Map, label: 'الخرائط', path: '/maps' },
  { icon: Settings, label: 'الإعدادات', path: '/settings' },
];

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  return (
    <aside className={`h-screen w-64 bg-gray-900 text-white p-4 fixed right-0 top-0 z-40 md:translate-x-0 transition-transform duration-300 ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
      <div className="flex items-center justify-between mb-8 pt-4 safe-area-top">
        <div className="flex items-center">
          <Map className="w-8 h-8 text-emerald-400" />
          <h1 className="text-xl font-bold mr-2">مساح برو</h1>
        </div>
        <button
          onClick={onClose}
          className="p-2 text-gray-400 hover:text-white md:hidden"
        >
          <X className="w-6 h-6" />
        </button>
      </div>
      
      <nav className="space-y-1">
        {menuItems.map((item) => (
          <NavLink
            key={item.label}
            to={item.path}
            onClick={onClose}
            className={({ isActive }) =>
              `flex items-center space-x-3 space-x-reverse p-3 rounded-lg transition-colors ${
                isActive ? 'bg-emerald-500 text-white' : 'text-gray-400 hover:bg-gray-800'
              }`
            }
          >
            <item.icon className="w-5 h-5" />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}