import { execSync } from 'child_process';
import { join } from 'path';

const ROOT_DIR = join(__dirname, '..');

async function build() {
  try {
    // Clean previous build
    console.log('🧹 Cleaning previous build...');
    execSync('rm -rf dist', { cwd: ROOT_DIR });

    // Build web assets
    console.log('🏗️ Building web assets...');
    execSync('npm run build', { cwd: ROOT_DIR });

    // Sync with Capacitor
    console.log('🔄 Syncing with Capacitor...');
    execSync('npm run cap:build', { cwd: ROOT_DIR });

    console.log('✅ Build completed successfully!');
  } catch (error) {
    console.error('❌ Build failed:', error);
    process.exit(1);
  }
}

build();